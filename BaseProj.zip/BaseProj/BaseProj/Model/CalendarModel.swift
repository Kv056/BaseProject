//
//  CalendarModel.swift
//  BaseProj
//
//  Created by Kirtan on 20/05/21.
//

import Foundation

struct CalendarResponseModel: Codable {
    let data: CalendarDataModel
    let message: String
    let error: Bool
}

struct CalendarDataModel: Codable {
    let id,user_id,plan_id: Int
    let created_at,updated_at,calendarjson:String
}
