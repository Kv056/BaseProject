//
//  RegisterUser.swift
//  BaseProj
//
//  Created by Kirtan on 20/05/21.
//

import Foundation

struct RegisteredUser: Codable {
    let data: RegisteredUserData
    let message: String
    let error: Bool
}

struct RegisteredUserData: Codable {
    let id: Int
    let firstname,lastname ,email: String
    let fcmtoken, verifyotp: String
    let verifyotpStatus: Int
    let createdAt, updatedAt, token: String
    let isTempLogin:Bool

    enum CodingKeys: String, CodingKey {
        case id,email,firstname,lastname,isTempLogin
        case fcmtoken, verifyotp
        case verifyotpStatus = "verifyotp_status"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
        case token
    }
}

