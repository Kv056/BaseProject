//
//  WebServiceConstant.swift
//  BaseProj
//
//  Created by Kirtan on 19/05/21.
//

import Foundation

    let token = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIzIiwianRpIjoiNzA2NDMxMjRlNGQ3MWU4OGM2ODU2ZWViMDJjYWM0MjRkNzViODdlNzNmODNmYTE5YWMxNWQ0NTU0ZjQxYTlkYzQwYzQxMjA2NzA5MDA3NDgiLCJpYXQiOjE2MjE1MDUyMjcsIm5iZiI6MTYyMTUwNTIyNywiZXhwIjoxNjUzMDQxMjI3LCJzdWIiOiI1Iiwic2NvcGVzIjpbXX0.RmYrIWXsBx1w6RG0nqsAFbYS6RUT4EpqdwqabPIAwMefTjmDAGvx8QVTunCMNO_tuHaVUT8oCzKyyZGlyXQ4gqe5vNr3rfKwA7i5okDievxKKyaE3pIbGu0hm4Hh94KB1Y3ElIi1PnLfMi_Lv6JNtOmCsWDMwttrsY_lDeIeIhWCb_XDiGIduHKfJSYrI972T5cBUff80yGX9RLATHuxu28JPFi8mVctEodmgDjocCapxr8gP_Ydg3JFjtAEDcwjnyeoXqqhsI90WfVIFjFNKAKjm98DclCALfJzga91BR2bU3zGSq0QepYkKtNB4PtLRwxHLf-U_Jmpjd3yfPJTSojCWq3w3T2KIbAxEM52JQD1I2EiVERZm1xEGnGiLQ1X_chbVyGi3JoCyBlW07-6eLTaEbA5qC6M64uCWRFDAjNr7yiSolsd3-84lsjvPWslN1C02Guucp4l3WOO_pXTApw_-NK1OqxGoMRw224SlX_NGEGcNeATx-uU_ZlPkyfTTifmvJUsqX2zdT85HSM2jRBq4wL99V_14G5iDa8VsTYwH97xeg1OzIltFFRenxXCj021HT5-uCNOd93kLwU0IDkv7J-eKdJ87K1NqpKxYS6w6Tp91yNCZgyHnvkxSdjaEVXI-WqFWu7BcG1axmDDdo6QAskw3av8BlniLPSadVE"

    struct WebServiceURL{
        static let live = "https://shaschabura.app/api/"
    }
    
    enum WSEndPoints:String{
        case calendarGet        = "calendarget"
        case login              = "login"
    }

