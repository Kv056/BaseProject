//
//  DataManager.swift
//  BaseProj
//
//  Created by Kirtan on 19/05/21.
//

import UIKit

class DataManager: NSObject {
    
//MARK:Variable
    static let shared = DataManager()
    let baseURL = WebServiceURL.live
    
//MARK:functions
    func getURL(endPoint:WSEndPoints) -> String{
        return baseURL + endPoint.rawValue
    }
    
    func getURLWithService(_ endpoint: WSEndPoints, data: String?) -> String {
        if data != nil {
            return baseURL + endpoint.rawValue + "?" + data!
        }
        return baseURL + endpoint.rawValue
    }
}
