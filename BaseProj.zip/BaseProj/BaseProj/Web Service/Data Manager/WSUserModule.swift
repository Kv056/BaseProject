//
//  WSUserModule.swift
//  BaseProj
//
//  Created by Kirtan on 19/05/21.
//

import Foundation

extension DataManager{
    
    func getCalendarPlan(completion:@escaping(_ response:[String:Any]?,_ calendarModel:CalendarResponseModel?,_ error:String?)->Void){

        NetworkManager.shared.getRequest(url: getURL(endPoint: .calendarGet), header: token, model: CalendarResponseModel.self) { (response, responseModel, error) in
            if error != nil{
                completion (nil, nil, error)
            }else{
                guard let userData = responseModel as? CalendarResponseModel else {
                    completion (nil, nil, "Decoding error")
                    return
                }
                completion (response, userData, nil)
            }
        }
    }
    
    func signIn(params:[String:Any],completion:@escaping(_ response:[String:Any]?,_ responseModel:RegisteredUser?,_ error:String?)->Void){
        NetworkManager.shared.postRequest(url: getURL(endPoint: .login), header: token, params: params, model: RegisteredUser.self) { (response, responseModel, error) in
            if error != nil{
                completion (nil, nil, error)
            }else{
                if let model = responseModel as? RegisteredUser{
                    completion (response, model, error)
                }else{
                    completion (nil, nil, "decoding error")
                }
            }
           
        }
    }
}
