//
//  ViewController.swift
//  BaseProj
//
//  Created by Kirtan on 19/05/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        DataManager.shared.getCalendarPlan { (response, responseModel ,error) in
//            if error == nil{
//                print("response \(response)")
//                print("responseModel \(responseModel)")
//            }else{
//                print("error \(error)")
//            }
//        }
        
        DataManager.shared.signIn(params: ["email":"kirtan.kanhasoft@gmail.com","password":"123456"]) { (response, responseModel, error) in
            if error == nil{
                print(responseModel)
            }else{
                print(error)
            }
        }
    }


}

